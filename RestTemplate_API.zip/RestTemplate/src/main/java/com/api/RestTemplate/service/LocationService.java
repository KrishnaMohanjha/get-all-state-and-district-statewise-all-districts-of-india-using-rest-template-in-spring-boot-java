package com.api.RestTemplate.service;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class LocationService {

    @Autowired
    private final RestTemplate restTemplate = new RestTemplate();

    public String getAllDistrictsAndStates() {
        String url = "http://api.nightlights.io/districts";
        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
        return response.getBody();
    }

    public String getDistrictsByState(String stateName) {
        String responseBody = getAllDistrictsAndStates();
        JSONObject jsonObject = new JSONObject(responseBody);
        JSONArray regions = jsonObject.getJSONArray("regions");

        JSONArray filteredDistricts = new JSONArray();
        for (int i = 0; i < regions.length(); i++) {
            JSONObject region = regions.getJSONObject(i);
            if (stateName.equals(region.getString("state_name"))) {
                filteredDistricts.put(region);
            }
        }

        JSONObject result = new JSONObject();
        result.put("regions", filteredDistricts);
        return result.toString();
    }

 

   
}
