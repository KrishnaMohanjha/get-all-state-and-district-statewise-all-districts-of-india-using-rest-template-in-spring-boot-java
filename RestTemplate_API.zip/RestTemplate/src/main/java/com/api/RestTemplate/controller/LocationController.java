package com.api.RestTemplate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.api.RestTemplate.service.LocationService;

@RestController
@RequestMapping("/api/location")
public class LocationController {

    @Autowired
    private LocationService locationService;

    @GetMapping("/districts-and-states")
    public String getDistrictsAndStates(@RequestParam(required = false) String stateName) {
        if (stateName != null && !stateName.isEmpty()) {
            return locationService.getDistrictsByState(stateName);
        } else {
            return locationService.getAllDistrictsAndStates();
        }
    }
    

    @GetMapping("/test")
    public String testEndpoint() {
        return "API is working!";
    }

 
}
